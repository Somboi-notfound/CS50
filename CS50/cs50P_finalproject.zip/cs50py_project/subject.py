from chapter import Chapter

class Subject:
  def __init__(self, name):
      self.name = name
      self.chapters = []
      self.total_chapters = len(self.chapters)

  def completed_chapters(self):
      count = 0
      for chapter in self.chapters:
          if chapter.completed_lectures == chapter.total_lectures:
              count += 1
      return count

  def view_chapters(self):
      print(f"\n{self.name} Chapters:\n")
      for i, chapter in enumerate(self.chapters, start=1):
          print(f"{i}. {chapter.name}")

  def select_chapter(self):
      print("\nChapters:\n")
      for i, chapter in enumerate(self.chapters, start=1):
          print(f"{i}. {chapter.name}")
      choice = int(input("\nChoose a chapter: "))
      return self.chapters[choice - 1]

  def add_chapter(self, chapter):
      if chapter not in self.chapters:
          self.chapters.append(chapter)
          self.total_chapters = len(self.chapters)
      else:
          print("Chapter already exists!")

  def progress(self):
      return (self.completed_chapters() / self.total_chapters) * 100

  def display(self):
      print(f"Subject: {self.name}")
      print(f"Chapters: {self.completed_chapters()}/{self.total_chapters}")
      print(f"Progress: {self.progress():.1f}%")

  def to_dict(self):
      return {"name": self.name, "chapters": [chapter.to_dict() for chapter in self.chapters]}

  @classmethod
  def from_dict(cls, data):
      subject = cls(data["name"])
      for chapter in data["chapters"]:
          subject.add_chapter(Chapter.from_dict(chapter))
      return subject