from chapter import Chapter
from subject import Subject
from tracker import StudyTracker
from default import PHYSICS, CHEMISTRY, MATHS
from study_planner import Planner
import os


tracker = StudyTracker()
tracker.load()

if len(tracker.subjects) == 0:
  physics = Subject("Physics")
  for name, lectures in PHYSICS:
      physics.add_chapter(Chapter(name, lectures))
  chemistry = Subject("Chemistry")
  for name, lectures in CHEMISTRY:
    chemistry.add_chapter(Chapter(name, lectures))
  maths = Subject("Maths")
  for name, lectures in MATHS:
    maths.add_chapter(Chapter(name, lectures))

def menu():
  print("\n" + "=" * 38)
  print("            STUDY TRACKER")
  print("=" * 38)
  print("""1. Dashboard
2. View Subjects
3. View Chapters
4. Study Lecture
5. Revise Chapter
6. Add Subject/Chapter
7. Open Study Planar
8. View Study Plan
9. Exit""")
  print("=" * 38)

while True:
  
  menu()

  choice = input("Enter your choice: ")
  if choice == "1":
      tracker.display_dashboard()
  elif choice == "2":
      tracker.view_subjects()
  elif choice == "3":
      subject = tracker.select_subject()
      subject.view_chapters()
  elif choice == "4":
      subject = tracker.select_subject()
      chapter = subject.select_chapter()
      print(f"\nCompleted: {chapter.completed_lectures}/{chapter.total_lectures}")
      lectures = int(input("How many lectures did you complete today? "))
      chapter.study_lecture(lectures)
      tracker.save()
      pass
  elif choice == "5":
      subject = tracker.select_subject()
      chapter = subject.select_chapter()
      chapter.revise()
      print(f"\nRevisions: {chapter.revision_count}")
      print("Chapter revised successfully!")
      tracker.save()
      pass
  elif choice == "6":
      tracker.save()
      print("Progress saved successfully!")
  elif choice == "7":
      print("Opening Study Planar...")
      os.system("python study_planner.py")
      try:
          planner = Planner(tracker)
          planner.calculate_plan()
          planner.save()
          tracker.save()
          pass
      except Exception as e:
          print(f"Error: {e}")
  elif choice == "8":
      planner = Planner(tracker)
      planner.view_plan()
      pass
  elif choice == "9":
      tracker.save()
      print("Progress saved. Goodbye!")
      break
  else:
      print("Invalid choice! Please try again.")