from subject import Subject
import json

class StudyTracker:
    def __init__(self):
        self.subjects = []

    def add_subject(self, subject):
        if subject not in self.subjects:
            self.subjects.append(subject)
        else:
            print("Subject already exists!")

    def overall_progress(self):
        if len(self.subjects) == 0:
            return 0
        total = 0
        for subject in self.subjects:
            total += subject.progress()
        return total / len(self.subjects)

    def display_dashboard(self):
        print("\n======= Study Tracker ========")
        for subject in self.subjects:
            print(f"{subject.name}: {subject.progress():.1f}%")
        print(f"\nOverall Progress: {self.overall_progress():.1f}%")

    def select_subject(self):
        print("\nSubjects:\n")
        for i, subject in enumerate(self.subjects, start=1):
            print(f"{i}. {subject.name}")
        choice = int(input("\nChoose a subject: "))
        return self.subjects[choice - 1]

    def view_subjects(self):
        print("\nSubjects:")
        for i, subject in enumerate(self.subjects, start=1):
            print(f"{i}. {subject.name}")

    def save(self):
        data = [subject.to_dict() for subject in self.subjects]
        with open("study_data.json", "w") as file:
            json.dump(data, file, indent=4)

    def load(self):
        try:
            with open("study_data.json", "r") as file:
                data = json.load(file)
            self.subjects = []
            for subject in data:
                self.subjects.append(Subject.from_dict(subject))
        except FileNotFoundError:
            print("No saved data found. Starting a new tracker.")