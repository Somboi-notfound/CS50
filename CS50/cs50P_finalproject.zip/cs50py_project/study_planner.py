import json
from datetime import datetime


class Planner:
    def __init__(self, tracker):
        self.tracker = tracker
        self.plan = {}
        self.file = "planner.json"
        self.load()

    def save(self):
        with open(self.file, "w") as f:
            json.dump(self.plan, f, indent=4)

    def load(self):
        try:
            with open(self.file, "r") as f:
                self.plan = json.load(f)
        except FileNotFoundError:
            self.plan = {}

    def get_exam_date(self):
        while True:
            try:
                date = input("Enter Exam Date (DD/MM/YYYY): ")
                exam_date = datetime.strptime(date, "%d/%m/%Y").date()
                today = datetime.today().date()
                days = (exam_date - today).days
                if days <= 0:
                    print("Exam date must be in the future.\n")
                    continue
                return days
            except ValueError:
                print("Invalid date format.\n")

    def get_study_info(self):
        while True:
            try:
                hours = float(input("Study hours per day: "))
                if hours <= 0:
                    print("Hours must be positive.\n")
                    continue
                break
            except ValueError:
                print("Enter a valid number.")
        while True:
            try:
                duration = float(input("Average lectures duration (in minutes): "))
                if duration <= 0:
                    print("Duration must be positive.\n")
                    continue
                break
            except ValueError:
                print("Enter a valid number.")
                
        lecture_perday = (hours * 60) / duration
        return lecture_perday

    def calculate_plan(self):
        days = self.get_exam_date()
        lecture_perday = self.get_study_info()
        remaining_lectures = sum(chapter.total_lectures - chapter.completed_lectures for subject in self.tracker.subjects for chapter in subject.chapters)
        effective_lecture_perday = lecture_perday / 2
        remaining_capacity = int(days * effective_lecture_perday)
        capacity = remaining_capacity
        self.plan = {}
        chapters = []
        for subject in self.tracker.subjects:
            for chapter in subject.chapters:
                remaining = chapter.total_lectures - chapter.completed_lectures
                if remaining > 0:
                    chapters.append((subject.name, chapter, remaining))
        chapters.sort(key=lambda x: (x[1].priority, x[1].completed_lectures == 0))
        day = 1
        lectures_today = 0
        for subject, chapter, remaining in chapters:
            current = chapter.completed_lectures + 1
            while remaining > 0 and remaining_capacity > 0:
                if lectures_today >= effective_lecture_perday:
                    lectures_today = 0
                    day += 1
                available = int(effective_lecture_perday - lectures_today)
                if available <= 0:
                    lectures_today = 0
                    day += 1
                    continue
                studying = min(remaining, available, remaining_capacity)
                self.plan.setdefault(f"Day {day}", []).append({"subject": subject, "chapter": chapter.name, "lecture_start": current, "lecture_end": current + studying - 1 })
                current += studying
                remaining -= studying
                lectures_today += studying
                remaining_capacity -= studying
        self.save()
        planned = capacity - remaining_capacity
        if planned == remaining_lectures:
            planned = "All"
        
        print("\n========== STUDY PLAN ==========")
        print(f"Days available          : {days}")
        print(f"Study lectures/day      : {effective_lecture_perday:.1f}")
        print(f"Remaining lectures      : {remaining_lectures}")
        print(f"Lectures planned        : {planned}")
        print(f"Days used               : {day}")
        print(f"Planner saved to        : {self.file}")
        
        try:
            if planned < remaining_lectures:
                print(f"Lectures left unscheduled: {remaining_lectures - planned}")
        except:
            pass
        print("================================")

    def view_plan(self):
        if not self.plan:
            print("\nNo study plan found.")
            return
        while True:
            print("\n===== VIEW PLAN =====")
            print("1. View Full Plan")
            print("2. View Specific Day")
            print("3. Back")
            choice = input("Choose: ")
            if choice == "1":
                self.view_full_plan()
            elif choice == "2":
                self.view_day()
            elif choice == "3":
                return
            else:
                print("Invalid choice.")

    def view_full_plan(self):
        for day, tasks in self.plan.items():
            print(f"\n{day}")
            print("-" * 30)
            for task in tasks:
                start = task["lecture_start"]
                end = task["lecture_end"]
                if start == end:
                    lecture = f"Lecture {start}"
                else:
                    lecture = f"Lectures {start}-{end}"
                print(f"{task['subject']} | "f"{task['chapter']} | "f"{lecture}")

    def view_day(self):
        day = input("Enter day number: ")
        key = f"Day {day}"
        if key not in self.plan:
            print("Day not found.")
            return
        print(f"\n{key}")
        print("-" * 30)
        for task in self.plan[key]:
            start = task["lecture_start"]
            end = task["lecture_end"]

            if start == end:
                lecture = f"Lecture {start}"
            else:
                lecture = f"Lectures {start}-{end}"

            print(
                f"{task['subject']} | " f"{task['chapter']} | " f"{lecture}")