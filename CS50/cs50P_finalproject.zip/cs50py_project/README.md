# Study Tracker

## Description

JEE Study Tracker is a command-line application built in Python that helps students preparing for competitive exams such as JEE track their studies, monitor their progress, and plan upcoming lectures.

I have created this project because keeping track of hundreds of lectures across Physics, Chemistry, and Mathematics manually can become confusing. Instead of manually using spreadsheets or notebooks, this application stores progress automatically and provides an organized interface for managing studies.

The application is object-oriented and also saves all the progress using JSON, allowing users to close the program and continue later without losing data.

## Features

* Organizes subjects into chapters.
* Allows users to create a personalized lecture schedule based on their exam date and remaining lectures.
* Tracks completed lectures for every chapter.
* Calculates progress for each subject and its chapters.
* Calculates overall study progress.
* Records how many times each chapter has been revised.
* Saves progress automatically.
* Loads previous progress when the program starts.
* Generates a study plan based on the user's input.

## Files

### project.py

This is the entry point of the program. It contains the menu system and allows users to navigate through all available features.

### tracker.py

Contains the `StudyTracker` class. This class manages every subject in the application and calculates overall progress across all subjects.

### subject.py

Contains the `Subject` class. A subject stores multiple chapters and calculates subject-level statistics such as completed chapters and percentage progress.

### chapter.py

Contains the `Chapter` class. Each chapter stores its name, total lectures, completed lectures, revision count, priority and converting data to and from dictionaries for JSON storage.

### planner.py

Contains the study planner logic. It creates a study plan based on the user's selected subject, chapter and lecture goals.

### progress.json

Stores all user progress. This file is automatically updated whenever there is a progress change or the program exits so that progress is saved between sessions.

### test_project.py

Contains unit tests written with `pytest`. The tests verify important functionality such as chapter progress, revision counts, subject progress, tracker progress, and serialization.

## Design Choices

One of my biggest design decisions was separating the program into multiple classes instead of placing everything inside one large file. This makes the project easier to maintain and extend. The `Chapter`, `Subject`, and `StudyTracker` classes each have a single responsibility. This follows object-oriented programming principles and keeps the code organized.

Another design choice was using JSON for storage instead of a database. JSON is lightweight, human-readable, and perfectly suitable for a local command-line application. I also separated the study planner into its own module. This keeps planning logic independent from progress tracking, making the project easier to improve in the future.

## Challenges

One challenge was designing a structure that allowed progress to be saved between program executions. This required converting Python objects into dictionaries before saving them as JSON and bringing back those objects when loading the file.

Another challenge was setting up the Study Plannar based on the number of lectures completed and the exam date while ensuring enough time remains for self-study.

## Future Improvements

Some features I would like to add include:

* Addition of other subjects and chapters depending upon the competitive exam
* Automatic scheduling based on available study time
* Unique plans for weekends and holidays
* Graphical charts showing progress
* Deadline reminders and tracking
* Support for multiple users

## What I Learned

This project helped me gain experience with object-oriented programming, file handling, JSON serialization, exception handling, program organization across multiple modules, and testing with `pytest`. This project also helped me appreciate the importance of object-oriented programming. Separating responsibilities into classes made the code significantly easier to organize, maintain, and extend. It also improved my understanding of designing software that solves a real-world problem rather than implementing isolated programming exercises.