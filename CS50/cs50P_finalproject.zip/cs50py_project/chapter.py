class Chapter:
  def __init__(self, name, total_lectures, priority = 4):
      self.name = name
      self.total_lectures = total_lectures
      self.completed_lectures = 0
      self.revision_count = 0
      self.priority = priority

  def study_lecture(self, lectures):
      if self.completed_lectures + lectures <= self.total_lectures:
        self.completed_lectures += lectures
        if self.completed_lectures == self.total_lectures:
            print("Chapter completed!")
      else:
        print("There are only ", self.completed_lectures)

  def revise(self):
      self.revision_count += 1

  def progress(self):
      return (self.completed_lectures / self.total_lectures) * 100

  def display(self):
      print(f"Chapter: {self.name}")
      print(f"Lectures: {self.completed_lectures}/{self.total_lectures}")
      print(f"Revisions: {self.revision_count}")
      print(f"Progress: {self.progress():.1f}%")

  def to_dict(self):
      return {"name": self.name, "total_lectures": self.total_lectures, "completed_lectures": self.completed_lectures, "revision_count": self.revision_count, "priority": self.priority}

  @classmethod 
  def from_dict(cls, data):
        chapter = cls(data["name"], data["total_lectures"], data.get("priority", 4))
        chapter.completed_lectures = data["completed_lectures"]
        chapter.revision_count = data["revision_count"]
        return chapter