import pytest
from chapter import Chapter
from subject import Subject
from tracker import StudyTracker


def test_chapter_progress():
    chapter = Chapter("Kinematics", 10)
    chapter.study_lecture(4)
    assert chapter.progress() == 40.0


def test_revise():
    chapter = Chapter("Kinematics", 10)
    chapter.revise()
    chapter.revise()
    assert chapter.revision_count == 2


def test_subject_completed_chapters():
    subject = Subject("Physics")

    c1 = Chapter("Kinematics", 5)
    c2 = Chapter("Laws of Motion", 5)
    c1.study_lecture(5)
    
    subject.add_chapter(c1)
    subject.add_chapter(c2)
    assert subject.completed_chapters() == 1
    assert subject.progress() == 50.0


def test_tracker_overall_progress():
    tracker = StudyTracker()

    physics = Subject("Physics")
    chemistry = Subject("Chemistry")

    c1 = Chapter("A", 10)
    c2 = Chapter("B", 10)
    c1.study_lecture(10)
    
    physics.add_chapter(c1)
    chemistry.add_chapter(c2)
    tracker.add_subject(physics)
    tracker.add_subject(chemistry)
    assert tracker.overall_progress() == 50.0


def test_to_dict_and_from_dict():
    chapter = Chapter("Vectors", 8, priority=2)
    chapter.study_lecture(3)
    chapter.revise()
    data = chapter.to_dict()
    restored = Chapter.from_dict(data)

    assert restored.name == "Vectors"
    assert restored.total_lectures == 8
    assert restored.completed_lectures == 3
    assert restored.revision_count == 1
    assert restored.priority == 2